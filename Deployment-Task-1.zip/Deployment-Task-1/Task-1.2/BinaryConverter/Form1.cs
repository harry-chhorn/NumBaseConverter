﻿using System;
using System.Globalization;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BinaryConverter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            cmbMode.Items.AddRange(new[] { "Decimal", "Binary", "Hexadecimal" });
            cmbMode.SelectedIndex = 0;
            
        }

        private bool IsBinary(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return false;
            foreach (char c in s) if (c != '0' && c != '1') return false;
            return true;
        }

        private bool IsHex(string s)
        {
            if (string.IsNullOrWhiteSpace (s)) return false;
            foreach(char c in s) if (!Uri.IsHexDigit(c)) return false;
            return true;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {
            numBinary.Text = "";
            numDecimal.Text = string.Empty;
            numHex.Text = "";
            txtInput.Clear();
            txtInput.Focus();
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            string mode = cmbMode.SelectedItem?.ToString() ?? "";
            string input = txtInput.Text.Trim();
            try
            {
                int dec;

                switch (mode)
                {
                    case "Decimal":
                        if (!int.TryParse(input, out dec))
                            throw new Exception("Invalid decimal number.");
                        break;
                    case "Hexadecimal":
                        if (!IsHex(input))
                            throw new Exception("Invalid hexadecimal number.");
                        dec = int.Parse(input, NumberStyles.HexNumber);
                        break;
                    case "Binary":
                        if (!IsBinary(input))
                            throw new Exception("Invalid binary number.");
                        dec = Convert.ToInt32(input, 2);
                        break;

                    default:
                        MessageBox.Show("Please select an input type.");
                        return;

                }

                numDecimal.Text = dec.ToString();
                numBinary.Text = Convert.ToString(dec, 2);
                numHex.Text = dec.ToString("X");
                
            }

            catch
            {
                MessageBox.Show("Invalid input for the selected mode");
            }
            
        }

        private void txtInput_TextChanged(object sender, EventArgs e)
        {

        }

        private void exitBtn_Click(object sender, EventArgs e)
        {
            DialogResult iExit;

            iExit = MessageBox.Show("Are you sure?");

            if(iExit == DialogResult.OK)
            {
                Application.Exit();
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
