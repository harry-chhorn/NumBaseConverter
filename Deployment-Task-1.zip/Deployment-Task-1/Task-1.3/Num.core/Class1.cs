﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Globalization;

namespace Num.core
{
    public static class BaseConverter
    {
        public static int DecimalFromBinary(string binary) => Convert.ToInt32(binary, 2);
        public static int DecimalFromHex(string hex) => int.Parse(hex, NumberStyles.HexNumber );
        public static string BinaryFromDecimal(int dec) => Convert.ToString(dec, 2);
        public static string HexFromDecimal(int dec) => dec.ToString("X");
    }
}
