﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Num.validation
{
   public static class InputChecks
    {
        public static bool IsBinary(string s)
        {
            if (string.IsNullOrWhiteSpace(s)) return false;
            foreach (char c in s) if (c != '0' && c != '1') return false;
            return true;
        }
        public static bool IsHex(string s)
        {
            if (string.IsNullOrWhiteSpace (s)) return false; 
            foreach (char c in s) if (!Uri.IsHexDigit(c)) return false;
            return true;
        }

        public static bool IsDecimal(string s) => int.TryParse(s, out _);

    }
}
